<div id="content">
<div id="listing">
<h2>About us</h2>
<p>About us content comes here</p>

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



