<div id="content">
<div id="listing">
<h2>Terms of Service</h2>
<p>Terms of Service content comes here</p>

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



