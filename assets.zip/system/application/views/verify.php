<div id="content">
<div id="listing">
		<h1 class="content_title">Sign up</h1>
		<br/>
			Please check your email address and verify your email address.

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



