<div id="content">
<div id="listing">
<h2>Order - Error</h2>
<p>	<?php echo $this->session->flashdata('message'); ?>
<br/><br/>
<p><b>TheGigBazaar Team</b></p></p>

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



