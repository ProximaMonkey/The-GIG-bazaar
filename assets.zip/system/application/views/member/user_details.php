<div id="content">
<div id="listing">

	<div id="user_layout">
	<div id="user_image">
			<img src='<?php echo base_url();?>/assets/timthumb.php?src=<?php echo $user['member_picture'];?>&h=56&w=56&zc=1' alt=''>
	</div>
	<div id="user_description">
	 <h2><?php echo $user['member_username'];?></h2><br/>
	<p><?php echo $user['member_description'];?></p>
	
	</div>

	<div id="user_gigs">
		<?php echo $gigs;?>
		
		
	</div>	
	</div><!--USer Layout-->

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



