<?php

	$config['facebook_api_key'] = '141916839183446';
	$config['facebook_secret_key'] = 'd8585332292e3242a05b792f34580f39';