<div id="content">
<div id="listing">
		<h1 class="content_title">Email Verification</h1>
			<br/>
				<?php echo $this->session->flashdata('message'); ?>

</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



