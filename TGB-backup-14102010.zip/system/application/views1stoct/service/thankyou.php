<div id="content">
<div id="listing">
		<h1 class="content_title">Thank you </h1><br/>
	<p>We have now received your order.</p>

	<p>Your order id is <b style="color:red;">#<?php echo $orderid;?></b></p>	

	<p> We have notified the user providing this service. </p><p>Once the user confirms the order, you will receive a notification of when your order will be delivered.
	</p>
	<p><b>TheGigBazaar Team</b></p>
</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



