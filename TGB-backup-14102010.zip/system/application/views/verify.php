<div id="content">
<?php $this->load->view('sidebar');?>
<div id="listing">
		<h1 class="content_title">Sign up</h1>
		<br/>
			Please check your email address and verify your email address.

</div><!--listing ends-->

</div><!--content ends-->



