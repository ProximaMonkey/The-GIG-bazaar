<div id="content">
<div id="listing">
<h2>Search Results</h2>


	<?php echo $gigs;?>
	
												<div class="pagination">
													<?php echo $pagination;?>
												</div>


</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



