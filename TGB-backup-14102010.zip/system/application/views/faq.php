<div id="content">
<div id="listing">

<div id="main-nav">
    	<ul>
	<li><a href="<?php echo site_url('main/recent');?>">recent</a> </li>
		<li><a href="<?php echo site_url('main/favorite');?>">most favorited</a> </li>  
	</ul>
   
	</div><!--main nav ends-->
    <?php $this->load->view('sidebar');?>
    
    
<h2>FAQ</h2>
</div><!--listing ends-->

<div class="clr"></div><!--clr ends-->
</div><!--content ends-->



