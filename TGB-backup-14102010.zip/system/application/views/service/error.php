<div id="content">
	<?php $this->load->view('sidebar');?>
<div id="listing">
<h2>Order - Error</h2>
<p>	<?php echo $this->session->flashdata('message'); ?>
<br/><br/>
<p><b>TheGigBazaar Team</b></p></p>

</div><!--listing ends-->

</div><!--content ends-->



