<div id="content">
	<?php $this->load->view('sidebar');?>
<div id="listing">
<h2>Order - Payment Cancelled</h2>
You cancelled the payment on the paypal page.<br/>

<a href='<?php echo site_url('main/index');?>'>Click here</a> to go back to the main page.<br/>
</p>

</div><!--listing ends-->

</div><!--content ends-->



