<div id="content">
		<?php $this->load->view('sidebar');?>
<div id="listing">

	<h1 class="content_title">Post a Job &rarr; Thank you</h1><br/>
		<br/>
			Thanks. Your service is now posted.

			<a href='<?php echo site_url('gig/single/'.$serviceid);?>'>Click here to view your service details</a>


</div><!--listing ends-->

</div><!--content ends-->



