<div id="content">
<div id="listing">
<h2>About us</h2>
<p>About us content comes here</p>
<?php $this->load->view('sidebar');?>
</div><!--listing ends-->

</div><!--content ends-->



