<div id="content">
<div id="listing">
	<h1 class="content_title">Post a Job &rarr; Thank you</h1><br/>
		<br/>
			Thanks. Your service is now posted.

			<a href='<?php echo site_url('service/single/'.$serviceid);?>'>Click here to view your service details</a>


</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



