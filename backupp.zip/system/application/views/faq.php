<div id="content">
<div id="listing">
<h2>FAQ</h2>
</div><!--listing ends-->
<?php $this->load->view('sidebar');?>
</div><!--content ends-->



