

<div id="footer">
	<hr>
	<span>&copy; All Rights Reserved. <a href="">How it works</a> | <a href="">Contact us</a> | <a href="">Blog</a></span>

	<div class="verisign-img footerimg"></div><!--verisign img-->
	<div class="pci-img footerimg"></div><!--vci-img ends-->
	<div class="pay">Pay with: </div>
	<div class="mastercard-img footerimg"></div><!--mastercard ends-->
	<div class="visa-img footerimg"></div><!--visa-img ends-->
	
</div>
</div><!--Content-->
</div><!--Wrapper-->


</body>
</html>