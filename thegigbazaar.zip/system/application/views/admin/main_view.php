<script type="text/javascript"><!--//--><![CDATA[//><!--
startList = function() {
if (document.all&&document.getElementById) {
cssdropdownRoot = document.getElementById("menu");
for (x=0; x<cssdropdownRoot.childNodes.length; x++) {
node = cssdropdownRoot.childNodes[x];
if (node.nodeName=="LI") {
node.onmouseover=function() {
this.className+=" over";
}
node.onmouseout=function() {
this.className=this.className.replace(" over", "");
}
}
}
}
}

if (window.attachEvent)
window.attachEvent("onload", startList)
else
window.onload=startList;

//--><!]]></script>
<div id="content">
	
	<div class="listing">
		<h1 class="content_title">Dashboard</h1><br/>
		<ul id="menu">
		<li class="mainitems">
		<a href="">Gigs</a>
		<ul class="subuls" style="width: 15em">
		<li><a href="<?php echo site_url('admin/addgig');?>">Add a Gig</a></li>
		<li><a href="<?php echo site_url('admin/managegigs');?>">Manage gigs</a></li>
		</ul>
		</li>

		<li class="mainitems">
		<a href="">Category</a>
		<ul class="subuls" style="width: 15em">
		<li><a href="<?php echo site_url('admin/addcategory');?>">Add a Category</a></li>
		<li><a href="<?php echo site_url('admin/managecategory');?>">Manage Category</a></li>
		</ul>
		</li>
		
			<li class="mainitems">
			<a href="<?php echo site_url('admin/comments');?>">Comments</a>
			
			</li>
			
				<li class="mainitems">
				<a href="">Payments</a>
				<ul class="subuls" style="width: 15em">
				<li><a href="<?php echo site_url('admin/recentpayment');?>">Recent Payment</a></li>
				<li><a href="<?php echo site_url('admin/paymentreport');?>">Generate Reports</a></li>
				</ul>
				</li>
				
					<li class="mainitems">
					<a href="">Users</a>
					<ul class="subuls" style="width: 15em">
					<li><a href="<?php echo site_url('admin/approveuser');?>">Approve a User</a></li>
					<li><a href="<?php echo site_url('admin/manageuser');?>">Manage user</a></li>
					</ul>
					</li>
				
		</ul>

		<div id="restofcontent">
		<br />
		<b>Welcome Administrator</b>
		<br/><small>You last logged in at June 25th at 5:04 PM</small><br/>
		
		<div id="dashboard">
		
		<div id="date">25th June</div>
		<ul>
			<li> - User <a href="">Admin</a>,<a href="">sunil</a> and <a href="">Sanat</a> joined the system
				
			<li> - Total of 4 new gigs were added
				
			<li> - 25 Jobs were ordered.
				
			<li> - 3 new comments were posted
		
		</ul>
				
		<div id="date">24th June</div>
			<ul>
				<li> - User <a href="">Admin</a> joined the system

				<li> - Total of 4 new gigs were added

				<li> - 25 Jobs were ordered.

				<li> - 3 new comments were posted

			</ul>
			<div id="date">23rd June</div>
				<ul>
					<li> - User <a href="">Admin</a> joined the system

					<li> - Total of 4 new gigs were added

					<li> - 25 Jobs were ordered.

					<li> - 3 new comments were posted

				</ul>
		
				<div id="date">22nd June</div>
					<ul>
						<li> - User <a href="">Admin</a> joined the system

						<li> - Total of 4 new gigs were added

						<li> - 25 Jobs were ordered.

						<li> - 3 new comments were posted

					</ul>
		
		</div>
		
	
		</div>
	</div><!-- Listing -->
	
	<div class="sidebar">
		<div id="sidebar_title">Browse by Category</div>
		<div class="sidebar_nav">
			<ul>
			<?php echo $category;?>
			</ul>
		</div>

		<div id="sidebar_title">Search</div>
		<form action="<?php echo site_url('service/search');?>" method="post">
		<table class="searchTable">
		<tr><td>
		 <input id="q" name="q" type="text" class="searchbar" /><input class="searchButton" type=submit id="Submit1"  value="Search" />
		</td>
		</tr>
		</table>

		</form>
		
	</div>
	
